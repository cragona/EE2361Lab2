/* 
 * File:   asm_ragon005_lab2b_mainv001.h
 * Author: Charlie
 *
 * Created on February 1, 2018, 9:52 PM
 */

#ifndef ASM_RAGON005_LAB2B_MAINV001_H
#define	ASM_RAGON005_LAB2B_MAINV001_H

#ifdef	__cplusplus
extern "C" {
#endif
    void write_0a(void);
    void write_1a(void);
    void oneMilliSec(void);

#ifdef	__cplusplus
}
#endif

#endif	/* ASM_RAGON005_LAB2B_MAINV001_H */

